const pages = ['Home', 'About', 'Resume','Projects', 'Contact'];
// const settings = ['Profile', 'Account', 'Dashboard', 'Logout'];


export { pages }